package com.smartherd.todolisttmm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.SparseBooleanArray
import android.view.View
import android.widget.*



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initializing the array lists and the adapter
        var itemlist = arrayListOf<String>()
        var adapter = ArrayAdapter<String>(this,
            android.R.layout.simple_list_item_multiple_choice
            , itemlist)        // Adding the items to the list when the add button is pressed

        val addBtn =    findViewById<Button>(R.id.add)
        val clearBtn =    findViewById<Button>(R.id.clear)
        val deleteBtn =    findViewById<Button>(R.id.delete)
        val myEditTxt =findViewById<TextView>(R.id.editText)
        val mylistview =findViewById<ListView>(R.id.listView)
        addBtn.setOnClickListener {

            itemlist.add(myEditTxt.text.toString())
            mylistview.adapter =  adapter
            adapter.notifyDataSetChanged()
            // This is because every time when you add the item the input space or the eidt text space will be cleared
            myEditTxt.text = ""
        }
        // Clearing all the items in the list when the clear button is pressed
        clearBtn.setOnClickListener {

            itemlist.clear()
            adapter.notifyDataSetChanged()
        }
        // Adding the toast message to the list when an item on the list is pressed
        mylistview.setOnItemClickListener { adapterView, view, i, l ->
            Toast.makeText(this, "You Selected the item --> "+itemlist.get(i), Toast.LENGTH_SHORT).show()
        }
        // Selecting and Deleting the items from the list when the delete button is pressed
        deleteBtn.setOnClickListener {
            val position: SparseBooleanArray = mylistview.checkedItemPositions
            val count = mylistview.count
            var item = count - 1
            while (item >= 0) {
                if (position.get(item))
                {
                    adapter.remove(itemlist.get(item))
                }
                item--
            }
            position.clear()
            adapter.notifyDataSetChanged()
        }
    }
}